package com.zybooks.mobile2appinventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Main inventory screen. Displays all items from the database in a three-column
 * grid where tapping a card opens its details screen and a button allows easy
 * adding of new items.
 */

public class MainActivity extends AppCompatActivity {

    private InventoryRepository repository;
    private ItemAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        repository = new InventoryRepository(getApplication());
        adapter = new ItemAdapter(item -> {
            Intent intent = new Intent(this, ItemDetailsActivity.class);
            intent.putExtra("item_id", item.getItemID());
            startActivity(intent);
        });

        RecyclerView recyclerView = findViewById(R.id.inventory_recycler_view);

        // Adapter only reports taps, allowing this activity to own its navigation
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        recyclerView.setAdapter(adapter);

        Button addItemButton = findViewById(R.id.add_item_button);
        addItemButton.setOnClickListener(view -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        Button logoutButton = findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(view -> {
            startActivity(new Intent(this, LogInActivity.class));
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Runs on first launch and every return from another activity so the grid re-queries
    // the database. This is why AddItem and ItemDetails need no refresh code of their own.
    @Override
    protected void onResume() {
        super.onResume();
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            List<Item> items = repository.getAllItems();
            runOnUiThread(() -> adapter.setItems(items));
        });
    }
}