package com.zybooks.mobile2appinventory;

import androidx.room.*;
import com.zybooks.mobile2appinventory.Item;
import java.util.List;


@Dao
public interface ItemDAO {

    @Insert
    void insertItem(Item item);

    @Query("SELECT * FROM Item ORDER BY itemName ASC")
    List<Item> getAllItems();

    @Query("SELECT * FROM Item WHERE _id = :id")
    Item getItemByID(long id);

    @Update
    void updateItem(Item item);

    @Delete
    void deleteItem(Item item);
}
