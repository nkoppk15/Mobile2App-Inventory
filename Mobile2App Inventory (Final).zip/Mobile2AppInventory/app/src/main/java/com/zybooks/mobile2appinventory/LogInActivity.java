package com.zybooks.mobile2appinventory;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.inputmethod.EditorInfo;


/**
 * App entry point. Validates credentials against User table and
 * handles new account creation. Launches MainActivity on successful login.
 */
public class LogInActivity extends AppCompatActivity {

    private InventoryRepository repository;

    EditText usernameEditText;
    EditText passwordEditText;
    Button newUserButton;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_log_in);

        usernameEditText = findViewById(R.id.username_input);
        passwordEditText = findViewById(R.id.password_input);
        newUserButton = findViewById(R.id.new_user_button);
        loginButton = findViewById(R.id.login_button);

        repository = new InventoryRepository(getApplication());

        // Pressing Done/Enter on keyboard behaves like tapping the login button so
        // perform click reuses the button's listener to trigger the same code.
        passwordEditText.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getAction() == KeyEvent.ACTION_DOWN
                    && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                loginButton.performClick();
                return true;
            }
            return false;
        });

        // Opens database while user looks at login screen to prevent slow open on emulator.
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            InventoryDatabase.getDatabase(getApplicationContext());  // forces open + seed now
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login_activity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loginButton.setOnClickListener(view -> {
            String[] credentials = getValidatedCredentials();
            if (credentials == null) {
                return;
            }
            // Database call off main thread, UI updates via runOnUIThread
            InventoryDatabase.databaseWriteExecutor.execute(() -> {
                User user = repository.loginUser(credentials[0], credentials[1]);
                Log.d("LoginDebug", "query returned: " + (user == null ? "null" : user.getUsername()));
                runOnUiThread(() -> {
                    if (user != null) {
                        loginButton.setEnabled(false);
                        Intent intent = new Intent(this, MainActivity.class);
                        startActivity(intent);
                        // finish() here prevents back from returning to logged-out inventory screen
                        finish();
                    } else {
                        loginButton.setEnabled(true);
                        Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });

        // For new accounts, dialog confirms intent before writing to prevent accidental creation
        newUserButton.setOnClickListener(view -> {
            String[] credentials = getValidatedCredentials();
            if (credentials == null) {
                return;
            }

            InventoryDatabase.databaseWriteExecutor.execute(() -> {
                boolean taken = repository.usernameExists(credentials[0]);

                // Check for duplicate username before showing dialog
                runOnUiThread(() -> {
                    if (taken) {
                        usernameEditText.setError("Username is already taken");
                        usernameEditText.requestFocus();
                    }
                    else {
                        showCreateAccountDialog(credentials);
                    }
                });
            });
        });
    }

    // Input gate for both buttons. Returns {username, password} when valid or
    // null after showing a setError() when either field is empty or password
    // is too short.
    private String[] getValidatedCredentials() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();

        boolean valid = true;

        if (username.isEmpty()){
            usernameEditText.setError("Enter a username");
            valid = false;
        }
        if (password.isEmpty()) {
            passwordEditText.setError("Enter a password");
            valid = false;
        }
        else if (password.length() < 8) {
            passwordEditText.setError("Minimum 8 characters");
            valid = false;
        }

        if (!valid) {
            usernameEditText.requestFocus();
            return null;
        }

        return new String[] {username, password};

    }

    // Dialog builder that sets up the dialog for confirming User creation
    private void showCreateAccountDialog(String[] credentials) {
        new AlertDialog.Builder(this)
                .setTitle("Create Account")
                .setMessage("Create account for \"" + credentials[0] + "\"?")
                .setPositiveButton("Create", (dialog, which) -> {
                    repository.insertUser(new User(0, credentials[0], credentials[1]));

                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }


}