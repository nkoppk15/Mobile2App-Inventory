package com.zybooks.mobile2appinventory;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "_id")
    private long userID;
    @NonNull
    @ColumnInfo(name ="username")
    private String username;
    @NonNull
    @ColumnInfo(name = "password")
    private String password;

    public User(long userID, String username, String password) {
        this.userID = userID;
        this.username = username;
        this.password = password;
    }

    public void setUserID (long ID) {
        this.userID = ID;
    }


    public long getUserID () {
        return userID;
    }

    public void setUsername (String username) {
        this.username = username;
    }

    public String getUsername () {
        return username;
    }

    public void setPassword (String password) {
        this.password = password;
    }

    public String getPassword () {
        return password;
    }

}
