package com.zybooks.mobile2appinventory;

import android.app.Application;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
public class InventoryRepository {
    private UserDAO userDAO;
    private ItemDAO itemDAO;

    /**
     * Single access point for the database. Activities never tough DAOs, instead
     * calling repository methods which run operations on executor and hand results back.
     * @param application
     */
    public InventoryRepository(Application application) {
        InventoryDatabase db = InventoryDatabase.getDatabase(application);
        userDAO = db.userDAO();
        itemDAO = db.itemDAO();
    }

    // =====================================
    // USER METHODS
    // =====================================

    // This style queues write and returns immediately which is safe since nothing depends on
    // the write finishing before next screen appears.
    public void insertUser(User user) {
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            userDAO.insertUser(user);
        });
    }

    // submit() returns a Future and get() waits for the answer. The caller is responsible
    // for running this off main thread using databaseWriteExecutor. Used when caller needs
    // result before continuing. Ex: login cant happen until user is validated.
    public User loginUser(String username, String password) {
        Future<User> future = InventoryDatabase.databaseWriteExecutor.submit(() ->
                userDAO.getUser(username, password)
        );
        try {
            return future.get();
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean usernameExists(String username) {
        Future<User> future = InventoryDatabase.databaseWriteExecutor.submit(() ->
                userDAO.getUserByUsername(username)
        );

        try {
            return future.get() != null;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =====================================
    // ITEM METHODS
    // =====================================


    public void insertItem(Item item) {
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            itemDAO.insertItem(item);
        });
    }

    public Item getItem(long id) {
        Future<Item> future = InventoryDatabase.databaseWriteExecutor.submit(() ->
                itemDAO.getItemByID(id)
        );

        try {
            return future.get();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void updateItem(Item item) {
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
                itemDAO.updateItem(item);
        });
    }

    public List<Item> getAllItems() {
        Future<List<Item>> future = InventoryDatabase.databaseWriteExecutor.submit(() ->
                itemDAO.getAllItems()
        );

        try {
            return future.get();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void deleteItem(Item item){
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            itemDAO.deleteItem(item);
        });
    }



}
