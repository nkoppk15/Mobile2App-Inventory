package com.zybooks.mobile2appinventory;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;


/**
 * Bridges the item list to the grid. RecyclerView only recycles holders and this adapter
 * owns the data, binding one item's values to each recycled card.
 */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    private final List<Item> items = new ArrayList<>();
    private final OnItemClickListener listener;

    public ItemAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Full list replacement (ok within scope)
    public void setItems(List<Item> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    // RecyclerView has no built-in click handling. NO_POSITION check
    // protects against taps landing on a card mid-recycle where its position
    // is invalid.
    public static class ItemViewHolder extends RecyclerView.ViewHolder{

        public final TextView nameText, skuText, quantityText;
        public ItemViewHolder(@NonNull View itemView, OnItemClickListener listener,
                              List<Item> items) {

            super(itemView);
            nameText = itemView.findViewById(R.id.item_name_text);
            skuText = itemView.findViewById(R.id.item_sku_text);
            quantityText = itemView.findViewById(R.id.item_quantity_text);

            itemView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(items.get(position));
                }
            });
        }
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_item, parent, false);
        return new ItemViewHolder(view, listener, items);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = items.get(position);
        holder.nameText.setText(item.getItemName());
        holder.skuText.setText(item.getItemSKU());
        holder.quantityText.setText("Qty: " + item.getItemQuantity());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}