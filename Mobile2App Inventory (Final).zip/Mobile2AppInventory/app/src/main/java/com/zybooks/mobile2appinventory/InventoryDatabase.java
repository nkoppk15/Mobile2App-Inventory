package com.zybooks.mobile2appinventory;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Room database singleton. Holds User and Item tables and exposes their DAOs.
 * All database access goes through one shared instance so the app never open the same
 * database file twice.
 */
@Database(entities = {User.class, Item.class}, version = 1, exportSchema = false)
public abstract class InventoryDatabase extends RoomDatabase {

    // Add DAOs into Room
    public abstract UserDAO userDAO();
    public abstract ItemDAO itemDAO();

    // ExecutorService to allow database operations to occur in the background
    private static final int NUMBER_OF_THREADS = 4;
    // Shared pool of threads for database operations. SQLite and UI thread are separate.
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    // Singleton Instance guarantees single database instance
    private static volatile InventoryDatabase INSTANCE;


    public static InventoryDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            // First check avoids lock once initialized, second check prevents two threads from
            // both building an instance
            synchronized (InventoryDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            InventoryDatabase.class, "inventory.db")
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }

        return INSTANCE;
    }

    // Runs only once when the database file is first created and seeds one test login
    // with sample inventory so fresh installation has data to work with.
    private static final RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            databaseWriteExecutor.execute(() -> {
                UserDAO userDAO = INSTANCE.userDAO();
                ItemDAO itemDAO = INSTANCE.itemDAO();

                // Add Test User (Username: admin, Password: password123)
                userDAO.insertUser(new User(0, "admin", "password123"));

                // 2. Add some test Items
                itemDAO.insertItem(new Item(0, "Wireless Mouse", "MOU-001", 15));
                itemDAO.insertItem(new Item(0, "Mechanical Keyboard", "KEY-002", 8));
                itemDAO.insertItem(new Item(0, "HD Monitor", "MON-003", 5));

            });
        }

    };
}
