package com.zybooks.mobile2appinventory;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.content.ContextCompat;

/**
 * SMS opt-in screen that shows current permission state, collects phone number,
 * requests SEND_SMS runtime permission, and sends alert for the item that hits 0.
 */


public class NotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 0;

    private TextView permissionLabel;
    private EditText phoneEditText;
    private String itemName;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notification);

        permissionLabel = findViewById(R.id.sms_permission_label);
        phoneEditText = findViewById(R.id.phone_number_input);
        itemName = getIntent().getStringExtra("item_name");
        Button enableSmsButton = findViewById(R.id.enable_sms_button);
        Button backButton = findViewById(R.id.back_button);


        phoneEditText.setText(getSharedPreferences("inventory_prefs", MODE_PRIVATE)
                .getString("phone_number", ""));

        updatePermissionLabel();

        enableSmsButton.setOnClickListener(view-> {
            if (hasSmsPermission()) {
                onSmsEnabled();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[] {Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);

            }
        });

        backButton.setOnClickListener(view -> finish());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private boolean hasSmsPermission () {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionLabel() {
        permissionLabel.setText(hasSmsPermission()
            ? R.string.sms_permission_enabled
            : R.string.sms_permission_not_enabled);
    }


    // Denying permission here only means no SMS, user can still use app
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != SMS_PERMISSION_REQUEST_CODE) return;

        if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            onSmsEnabled();
        }
        else {
            updatePermissionLabel();
            Toast.makeText(this, "SMS alerts disabled -- the app will work without them.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Permission granted path persisting number so future alerts don't need input
    private void onSmsEnabled() {
        String phone = phoneEditText.getText().toString().trim();

        if (phone.isEmpty()) {
            Toast.makeText(this, "Enter a phone number to receive alerts", Toast.LENGTH_SHORT).show();
            return;
        }

        getSharedPreferences("inventory_prefs", MODE_PRIVATE)
                .edit()
                .putString("phone_number", phone)
                .apply();

        sendZeroAlertIfEnabled(this, itemName);
        finish();
    }

    // Gate for every SMS send. Returns false and does nothing unless both permission granted
    // and phone number is saved. False is treated as feature disabled and no code assumes SMS
    // is available.
    public static boolean sendZeroAlertIfEnabled(Context context, String itemName) {
        if (itemName == null || itemName.isEmpty()) return false;

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        String phone = context.getSharedPreferences("inventory_prefs", Context.MODE_PRIVATE)
                .getString("phone_number", "");
        if (phone == null || phone.isEmpty()) return false;

        SmsManager smsManager = context.getSystemService(SmsManager.class);
        smsManager.sendTextMessage(
                phone,
                null,
                "Inventory alert " + itemName + " has reached zero quantity in stock.",
                null,
                null);
        return true;
    }
}