package com.zybooks.mobile2appinventory;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


/**
 * Room entity for one inventory item. Each field maps to a column in the Item table
 * and constructor parameter names match field names for Room's code generation.
 */
@Entity
public class Item {

    // IDs are inserted with a 0 and SQLite assigns the real incremented ID
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "_id")
    private long itemID;
    @ColumnInfo(name = "itemName")
    private String itemName;
    @ColumnInfo(name = "itemSKU")
    private String itemSKU;
    @ColumnInfo(name = "itemQuantity")
    private int itemQuantity;

    public Item (long itemID, String itemName, String itemSKU, int itemQuantity) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemSKU = itemSKU;
        this.itemQuantity = itemQuantity;
    }

    public void setItemID (long ID) {
        this.itemID = ID;
    }

    public long getItemID () {
        return itemID;
    }

    public void setItemName (String name) {
        this.itemName = name;
    }

    public String getItemName () {
        return itemName;
    }

    public void setItemSKU (String SKU) {
        this.itemSKU = SKU;
    }

    public String getItemSKU () {
        return itemSKU;
    }

    public void setItemQuantity (int quantity) {
        this.itemQuantity = quantity;
    }

    public int getItemQuantity () {
        return itemQuantity;
    }

}
