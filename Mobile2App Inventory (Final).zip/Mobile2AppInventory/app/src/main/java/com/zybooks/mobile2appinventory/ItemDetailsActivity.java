package com.zybooks.mobile2appinventory;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Detail view for one item selected by itemId from the intent.
 * Quantity is edited in working copy and database is only written when user
 * confirms.
 */
public class ItemDetailsActivity extends AppCompatActivity {

    private InventoryRepository repository;
    private Item item;
    private EditText quantityEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_details);
        repository = new InventoryRepository(getApplication());

        TextView nameText = findViewById(R.id.item_details_name_textview);
        TextView skuText  = findViewById(R.id.item_details_sku_textview);
        quantityEditText      = findViewById(R.id.item_details_quantity_number);
        Button minusButton   = findViewById(R.id.minus_quantity_button);
        Button plusButton    = findViewById(R.id.plus_quantity_button);
        Button confirmButton = findViewById(R.id.confirm_quantity_button);
        Button cancelButton  = findViewById(R.id.cancel_quantity_button);
        Button deleteButton = findViewById(R.id.delete_item_button);

        long itemId = getIntent().getLongExtra("item_id", -1);

        // Get item by ID passed from the grid. Null closed the screen rather than showing empty layout.
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            item = repository.getItem(itemId);
            runOnUiThread(() -> {
                if (item == null) {
                    finish();
                    return;
                }
                nameText.setText(item.getItemName());
                skuText.setText("SKU : " + item.getItemSKU());
                quantityEditText.setText(String.valueOf(item.getItemQuantity()));
            });
        });

        minusButton.setOnClickListener(view -> {
            int current = parseQuantity();
            if (current > 0) {
                quantityEditText.setText(String.valueOf(current - 1));
            }
        });

        plusButton.setOnClickListener(view-> {
            int current = parseQuantity();
            quantityEditText.setText(String.valueOf(current + 1));
        });

        // Single write point. EditText value becomes item's quantity here alone.
        confirmButton.setOnClickListener(view -> {
            if (item != null) {
                int quantity = parseQuantity();
                item.setItemQuantity(quantity);
                repository.updateItem(item);

                // Zero quantity is alert trigger. If SMS is already enabled, send otherwise open
                // permission screen so user can opt in.
                if (quantity == 0) {
                    if (!NotificationActivity.sendZeroAlertIfEnabled(this, item.getItemName())) {
                        Intent intent = new Intent(this, NotificationActivity.class);
                        intent.putExtra("item_name", item.getItemName());
                        startActivity(intent);
                    }
                }
            }
            finish();
        });

        cancelButton.setOnClickListener(view -> finish());

        deleteButton.setOnClickListener(view -> {
            if(item == null) return;
            new AlertDialog.Builder(this)
                    .setTitle("Delete Item")
                    .setMessage("Delete \"" + item.getItemName() + "\" from inventory?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        repository.deleteItem(item);
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Helper function to allow direct editing of item quantity so confirm can never crash on bad input
    private int parseQuantity() {
        try{
            String text = quantityEditText.getText().toString().trim();
            return text.isEmpty() ? 0 : Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}