package com.zybooks.mobile2appinventory;

import androidx.room.*;
import com.zybooks.mobile2appinventory.User;
import java.util.List;

@Dao
public interface UserDAO {
    @Insert
    void insertUser(User user);

    @Query("SELECT * FROM User WHERE username = :user AND password = :pass")
    User getUser(String user, String pass);

    @Query("SELECT * FROM User WHERE username = :user LIMIT 1")
    User getUserByUsername(String user);

    //

}