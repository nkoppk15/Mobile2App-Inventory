package com.zybooks.mobile2appinventory;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Form for adding one inventory item. Validates locally and inserts via the repository, then
 * returns.
 */
public class AddItemActivity extends AppCompatActivity {

    private InventoryRepository repository;
    private EditText nameEditText, skuEditText, quantityEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        nameEditText = findViewById(R.id.add_item_name_input);
        skuEditText = findViewById(R.id.add_item_sku_input);
        quantityEditText = findViewById(R.id.add_item_quantity_input);
        Button confirmButton = findViewById(R.id.confirm_add_item_button);
        Button cancelButton = findViewById(R.id.cancel_add_item_button);

        repository = new InventoryRepository(getApplication());

        confirmButton.setOnClickListener(view -> {
            String name = nameEditText.getText().toString().trim();
            String sku = skuEditText.getText().toString().trim();
            String quantityText = quantityEditText.getText().toString().trim();

            if (name.isEmpty() || sku.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();

                return;
            }

            // Integer.parseInt throws on non-numeric, catching it converts crash into message
            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            repository.insertItem(new Item(0, name, sku, quantity));
            finish();
        });

        cancelButton.setOnClickListener(view-> finish());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.add_item), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}